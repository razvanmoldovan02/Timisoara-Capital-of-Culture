export interface MyEvent{

    id: number;
    name: string;
    startDate: Date;
    endDate: Date;
    organizer: string;
    location: string;
    description: string;
    path: string;
}